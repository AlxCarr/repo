module Practica_2 {
	requires junit;

}