package ProbaUnit;

import static org.junit.Assert.*;

import org.junit.Test;

import probes.ProbaUnit;

public class TestProbaUnit {

	@Test
	public void order1() {
		int f1 = 1;
		int f2 = 2;
		int f3 = 3;
		
		String val = (new ProbaUnit()).order(f1,f2,f3);
	}

	@Test
	public void order2() {
		int f1 = 2;
		int f2 = 1;
		int f3 = 3;
		
		String val = (new ProbaUnit()).order(f1,f2,f3);
	}
	@Test
	public void order3() {
		int f1 = 3;
		int f2 = 1;
		int f3 = 2;
		
		String val = (new ProbaUnit()).order(f1,f2,f3);
	}
	@Test
	public void order4() {
		int f1 = -1;
		int f2 = 0;
		int f3 = 10;
		
		String val = (new ProbaUnit()).order(f1,f2,f3);
	}
}
